package com.example.epics;

public class ResponsePOJO {

    private  boolean status;
    private String remarks;

    public boolean isStatus() {
        return status;
    }

    public String getRemarks() {
        return remarks;
    }
}
