package com.example.epics;

public class Constants {
    public static String KEY_EMAIL = "email";
    public static String KEY_PASSWORD = "password";
    public static String KEY_USERNAME = "username";
    public static String KEY_NAME = "name";
}